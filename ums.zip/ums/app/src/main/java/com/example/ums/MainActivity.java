package com.example.ums;

import java.io.DataOutputStream;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);				
		
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}
	
    public void onClick(View v) {
        final int id = v.getId();
        switch (id) {
        case R.id.button1:

            try {

            	Process p = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
            	os.writeBytes("setprop persist.sys.usb.config adb\n");
//            	os.writeBytes("echo /dev/block/vold/179:17 > /sys/devices/platform/s3c-usbgadget/gadget/lun0/file\n");
            	os.writeBytes("echo /dev/block/vold/179:17 > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun0/file\n");
            	os.writeBytes("setprop persist.sys.usb.config mass_storage,adb\n");
            	os.writeBytes("exit\n");
                os.flush();
                os.close();
                int exitcode = p.waitFor();        	
            	p.destroy();
                Toast.makeText(getApplicationContext(), "UMS Sharing physical SD card lun0 ", Toast.LENGTH_SHORT).show();
               
            } catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
            } catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            Toast.makeText(getApplicationContext(), "Finished sharing sdcard", Toast.LENGTH_SHORT).show();
        	
            break;

        case R.id.button2:
        	
            try {

            	Process p = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
            	os.writeBytes("setprop persist.sys.usb.config adb\n");
            	os.writeBytes("busybox losetup /dev/block/loop0 /data/mnttest.img\n");            	
//            	os.writeBytes("echo /dev/block/loop0 > /sys/devices/platform/s3c-usbgadget/gadget/lun0/file\n");
            	os.writeBytes("echo /dev/block/loop0 > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun0/file\n");
            	os.writeBytes("setprop persist.sys.usb.config mass_storage,adb\n");
                //os.writeBytes("/data/umsloop.sh\n");
                os.writeBytes("exit\n");
                os.flush();
                os.close();
                int exitcode = p.waitFor();        	
            	p.destroy();
                Toast.makeText(getApplicationContext(), "UMS Sharing mnttest.img on loop0", Toast.LENGTH_SHORT).show();
                
            } catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
            } catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            Toast.makeText(getApplicationContext(), "Finished share loop0", Toast.LENGTH_SHORT).show();
            
            break;
            
        case R.id.button3:
        	
            try {

            	Process p = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
            	os.writeBytes("setprop persist.sys.usb.config adb\n");
            	os.writeBytes("busybox losetup /dev/block/loop1 /data/mnttest1.img\n");            	
//            	os.writeBytes("echo /dev/block/loop1 > /sys/devices/platform/s3c-usbgadget/gadget/lun1/file\n");
            	os.writeBytes("echo /dev/block/loop1 > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun1/file\n");
            	os.writeBytes("setprop persist.sys.usb.config mass_storage,adb\n");
                //os.writeBytes("/data/umsloop.sh\n");
                os.writeBytes("exit\n");
                os.flush();
                os.close();
                int exitcode = p.waitFor();        	
            	p.destroy();
                Toast.makeText(getApplicationContext(), "UMS Sharing mnttest.img on loop1", Toast.LENGTH_SHORT).show();
                
            } catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
            } catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            Toast.makeText(getApplicationContext(), "Finished share loop1", Toast.LENGTH_SHORT).show();

            break;
            
        case R.id.button4:
        	
            try {

            	Process p = Runtime.getRuntime().exec("su");
            	//Process p = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
            	os.writeBytes("setprop persist.sys.usb.config adb\n");
//            	os.writeBytes("echo \"\" > /sys/devices/platform/s3c-usbgadget/gadget/lun0/file\n");
//            	os.writeBytes("echo \"\" > /sys/devices/platform/s3c-usbgadget/gadget/lun1/file\n");
//            	os.writeBytes("echo \"\" > /sys/devices/platform/s3c-usbgadget/gadget/lun2/file\n");
            	os.writeBytes("echo \"\" > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun0/file\n");
            	os.writeBytes("echo \"\" > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun1/file\n");
            	// stock oem only has 2 luns
            	os.writeBytes("echo \"\" > /sys/devices/virtual/android_usb/android0/f_mass_storage/lun2/file\n");
            	os.writeBytes("busybox losetup -d /dev/block/loop0\n");            	
            	os.writeBytes("setprop persist.sys.usb.config adb\n");
                os.writeBytes("exit\n");
                os.flush();
                os.close();
                int exitcode = p.waitFor();        	
            	p.destroy();
                Toast.makeText(getApplicationContext(), "UMS turned off", Toast.LENGTH_SHORT).show();
                
            } catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
            } catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            Toast.makeText(getApplicationContext(), "Finished UMS off", Toast.LENGTH_SHORT).show();
            
            break;
            // even more buttons here

        case R.id.button5:
        	
            try {
                EditText mEdit;
                mEdit   = (EditText)findViewById(R.id.editText);
                String count = mEdit.getText().toString();
                int intCount = Integer.parseInt(count);
                Toast.makeText(getApplicationContext(),"editText " + count, Toast.LENGTH_LONG).show();

            	Process p = Runtime.getRuntime().exec("su");
            	//Process p = Runtime.getRuntime().exec("su");
                DataOutputStream os = new DataOutputStream(p.getOutputStream());
                String cmd = "busybox dd if=/dev/zero of=/data/mnttest.img bs=1M count="+count+"\n";
//                os.writeBytes("busybox dd if=/dev/zero of=/data/mnttest.img bs=1M count=10\n");
//                Toast.makeText(getApplicationContext(),cmd, Toast.LENGTH_LONG).show();
                os.writeBytes(cmd);
            	os.writeBytes("busybox losetup /dev/block/loop2 /data/mnttest.img\n");
                intCount *= 1024;  // ds=1M but length is in KB
                String cmd1 = "busybox mkdosfs /dev/block/loop2 "+intCount+"\n";
//                os.writeBytes("busybox mkdosfs /dev/block/loop2 10240\n");
                os.writeBytes(cmd1);
                Toast.makeText(getApplicationContext(),cmd1, Toast.LENGTH_LONG).show();
            	os.writeBytes("busybox losetup -d /dev/block/loop2\n");
                os.writeBytes("exit\n");
                os.flush();
                os.close();
                int exitcode = p.waitFor();        	
            	p.destroy();
                Toast.makeText(getApplicationContext(), "New /data/mnttest.img size "+count+" created and formatted FAT", Toast.LENGTH_SHORT).show();
                
            } catch (java.io.IOException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
            } catch (InterruptedException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            Toast.makeText(getApplicationContext(), "Finished create new image file", Toast.LENGTH_SHORT).show();
            
            break;
        
        
        
        }
    }
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

}
